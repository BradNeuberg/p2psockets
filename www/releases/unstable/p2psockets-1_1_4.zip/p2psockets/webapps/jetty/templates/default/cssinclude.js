<script type="text/javascript">
<!-- Hide script contents from old browsers

    var IE4 = (document.all && !document.getElementById) ? true : false;
    var NS4 = (document.layers) ? true : false;
    var IE5 = (document.all && document.getElementById) ? true : false;
    var NS6 = (document.getElementById && !document.all) ? true : false;
    var IE  = IE4 || IE5;
    var NS  = NS4 || NS6;
    var Mac = (navigator.platform.indexOf("Mac") == -1) ? false : true;

    var sheet;

    if( NS4 )
    {
        sheet = "jspwiki_ns.css";
    }
    else if( Mac )
    {
        sheet = "jspwiki_mac.css";
    }
    else
    {
        // Let's assume all the rest of the browsers are sane
        // and standard's compliant.
        sheet = "jspwiki_ie.css";
    }

    document.write("<link rel=\"stylesheet\" href=\"templates/<wiki:TemplateDir/>/"+sheet+"\">");

// end hiding contents from old browsers -->
</script>

<meta http-equiv="Content-Type" content="text/html; charset=<wiki:ContentEncoding />">
<link rel="search" href="<wiki:LinkTo format="url" page="FindPage"/>"            title="Search <wiki:Variable var="ApplicationName" />">
<link rel="help"   href="<wiki:LinkTo format="url" page="TextFormattingRules"/>" title="Help">
<link rel="start"  href="<wiki:LinkTo format="url" page="Main"/>"                title="Front page">


/** 
 * Copyright (c) 2003 by Bradley Keith Neuberg, bkn3@columbia.edu.
 *
 * Redistributions in source code form must reproduce the above copyright and this condition.
 *
 * The contents of this file are subject to the Sun Project JXTA License Version 1.1 (the "License"); 
 * you may not use this file except in compliance with the License. A copy of the License is available 
 * at http://www.jxta.org/jxta_license.html.
 */

package org.p2psockets;

import java.io.*;

import net.jxta.peergroup.*;
import net.jxta.rendezvous.*;

import net.jxta.ext.config.*;

/**
 * This class signs us into the JXTA network.
 * It is meant to model the JXTA network as a whole.
 *
 * By default, we re-profile this peer every time it starts
 * up using the JXTA Profiler.  To turn off this behavior,
 * call the signin() method with the fourth boolean argument
 * set to false to indicate not to peform profiling.
 *
 * Threading: the entire object is locked if
 * any methods are called to mediate access
 * to the netPeerGroup.  
 * We are assuming net.jxta.peergroup.PeerGroup 
 * is thread-safe.
 *
 * @author Brad GNUberg, bkn3@columbia.edu
 * @version 0.6
 *
 * @todo Doesn't seem to work correctly if the peer itself is a Net Peer Group rendezvous.
 * @todo Create a constructor for initialize that takes an application string; this will 
 * hash the string into a peer group ID, and then find or create an application level
 * peer group.  We should also have an initialize() method that takes a PeerGroup object,
 * which will find or create the given peer group.  This first method is for those programmers
 * who don't know anything about Jxta, while the second is for those who know more.
 */
public class P2PNetwork {
	/** The system property name for setting the P2P network to sign into and initialize. */
	public static String P2PSOCKETS_NETWORK = "p2psockets.network";
	/** The system property name for the username of this Jxta peer.*/
	public static String JXTA_USERNAME = "net.jxta.tls.principal";
	/** The system property name for the password of this Jxta peer.*/
	public static String JXTA_PASSWORD = "net.jxta.tls.password";

	/** The system property name that specifies where to find the Jxta configuration
	  * files. */
	public static String JXTA_HOME = "JXTA_HOME";

	private static PeerGroup netPeerGroup;
    
    /** The name to use for scoping all server sockets and sockets. */
	private static String applicationName;

	private static boolean signedIn = false;

	/** Determines if an account exists for the given username.
	  */
	public static boolean accountExists(String userName) throws Exception {
        // FIXME: See if an account exists
        /*
		String jxtaHome = System.getProperty("JXTA_HOME", "." + File.separator + ".jxta");
		File homeDir = new File(jxtaHome);
		PSEConfig pseConfig = new PSEConfig(homeDir);

		return pseConfig.principalIsIssuer(userName, null);
        */
        throw new RuntimeException("not implemented");
	}

	/** Removes any old JXTA account and creates a new one, profiling the peer and signing
	  * them into the JXTA network.  This version of createAccount() uses the username and password
	  * given in the shell variables net.jxta.tls.principal and net.jxta.tls.password.
	  */
	public static void createAccount() throws Exception {
		String userName = System.getProperty(JXTA_USERNAME);
		String password = System.getProperty(JXTA_PASSWORD);

		if (userName == null || password == null) {
			throw new RuntimeException("You must provide a JXTA username and password by setting "
									   + JXTA_USERNAME + " and " + JXTA_PASSWORD);
		}
		
		createAccount(userName, password);
	}

	/** Removes any old JXTA account and creates a new one, profiling the peer and signing
	  * them into the JXTA network.  This version of createAccount() uses the
	  * application peer group name given in the shell variable p2psockets.network.
	  */
	public static void createAccount(String userName, String password) throws Exception {
		String appName = System.getProperty(P2PSOCKETS_NETWORK);
		if (appName == null) {
			throw new RuntimeException("You must either provide the system property "
									   + P2PSOCKETS_NETWORK + " when running your software, "
									   + "or code your application to use "
									   + "P2PNetwork.createAccount(String userName, String password, "
									   + "String applicationName)");
		}

		createAccount(userName, password, appName);
	}

	/** Removes any old JXTA account and creates a new one, profiling the peer and signing
	  * them into the JXTA network.
	  */
	public static synchronized void createAccount(String userName, String password, 
												  String appName) throws Exception {
		// make sure we aren't already signed in
		if (signedIn) {
			return;
		}
		
		// remove old .jxta installation
        String jxtaHome = System.getProperty("JXTA_HOME", "." + File.separator + ".jxta");
        System.out.println("[Creating Account] JXTA_HOME = " + jxtaHome);
		File jxtaDir = new File(jxtaHome);
		// make sure we actually have a value
		if (jxtaDir != null && !jxtaDir.equals("") && jxtaDir.toString().indexOf(".jxta") != -1) {
			System.out.println("Deleting JXTA configuration directory at " + jxtaDir + "...");
			jxtaDir.delete();
		}
		
        applicationName = appName;
        
        // set the username and the password
        System.setProperty(JXTA_USERNAME, userName);
        System.setProperty(JXTA_PASSWORD, password);
        
		// Profile this peer
		net.jxta.ext.config.Configurator config = 
            new net.jxta.ext.config.Configurator(userName, userName, password);
		boolean result = config.save();
		if (result == false)
            throw new Exception("Unable to save JXTA configuration");
       
		// boot the platform
		netPeerGroup = PeerGroupFactory.newNetPeerGroup();

		// wait around until we contact a rendezvous server
		if (netPeerGroup.isRendezvous() == false) 
			contactRendezVous(netPeerGroup);

		signedIn = true;
	}

	public static synchronized void signin() throws Exception {
		String userName = System.getProperty(JXTA_USERNAME);
		String password = System.getProperty(JXTA_PASSWORD);

		if (userName == null || password == null) {
			throw new RuntimeException("You must provide a JXTA username and password by setting "
									   + JXTA_USERNAME + " and " + JXTA_PASSWORD);
		}
		
		signin(userName, password);
	} 

	public static void signin(String userName, String password) throws Exception {
		String appName = System.getProperty(P2PSOCKETS_NETWORK);
		if (appName == null) {
			throw new RuntimeException("You must either provide the system property "
									   + P2PSOCKETS_NETWORK + " when running your software, "
									   + "or code your application to use "
									   + "P2PNetwork.signin(String userName, String password, "
									   + "String applicationName)");
		}

		signin(userName, password, appName, true);
	}

	public static void signin(String userName, String password, String appName) 
								throws Exception {
		signin(userName, password, appName, false);
	}

	/** @param userName The username to use for signing in.
	  * @param password The password to use for signing in.
	  * @param appName A unique string identifying your application.
	  * @param createIfNotExist Whether to create this account if it doesn't exist.
	  */
	public static synchronized void signin(String userName, String password, String appName,
										   boolean createIfNotExist) 
								throws Exception {
		// make sure we aren't already signed in
		if (signedIn) {
			return;
		}
		
		// see if there is a .jxta configuration directory yet; if not, then create an account
		// if the programmer wants this
        String jxtaHome = System.getProperty("JXTA_HOME", "." + File.separator + ".jxta");
        System.out.println("[Signing In] Using JXTA_HOME = " + jxtaHome);
		File homeDir = new File(jxtaHome);
		if (createIfNotExist == true && homeDir.exists() == false) {
			System.out.println("No JXTA account exists; creating one for " + userName + "...");
			createAccount(userName, password, appName);
			return;
		}
        
        applicationName = appName;

        // FIXME: make sure the username and password given are correct
        /*
        PSEConfig pseConfig = new PSEConfig(homeDir);

        if (!pseConfig.principalIsIssuer(userName, null) || 
            !pseConfig.validPasswd(password)) {
            throw new Exception("Invalid username or password given");
        }*/
        
        // set the username and the password
        System.setProperty(JXTA_USERNAME, userName);
        System.setProperty(JXTA_PASSWORD, password);
        
		// Profile this peer
        net.jxta.ext.config.Configurator config = 
            new net.jxta.ext.config.Configurator(userName, userName, password);
        boolean result = config.save();
        if (result == false)
            throw new Exception("Unable to save JXTA configuration");

		// boot the platform
		netPeerGroup = PeerGroupFactory.newNetPeerGroup();

		// wait around until we contact a rendezvous server
		if (netPeerGroup.isRendezvous() == false) 
			contactRendezVous(netPeerGroup);
        
		signedIn = true;
	}

	/** Signs us out of the P2P network.  
	  * FIXME: Actually do something here.
	  */
	public static void signOff() throws Exception {
		signedIn = false;
        throw new RuntimeException("not implemented");
	}

	public static synchronized PeerGroup getNetPeerGroup() {
		if (netPeerGroup == null) {
			throw new RuntimeException("You must call P2PNetwork.signin() before "
									   + " attempting to use this class");
		}

		return netPeerGroup;
	}

	public static synchronized void setApplicationName(String appName) {
		applicationName = appName;
	}

	public static synchronized String getApplicationName() { return applicationName; }

	protected static void contactRendezVous(PeerGroup inGroup) throws Exception {
		// contact a rendezvous server
		RendezVousService rdv = inGroup.getRendezVousService();
		System.out.print("Waiting for RendezVous Connection.");
		System.out.flush();

		int timeSoFar = 0;
		while (!rdv.isConnectedToRendezVous() && timeSoFar < 120000) { // 2 minutes
			System.out.print(".");
			System.out.flush();
			Thread.currentThread().sleep(1000);
			timeSoFar += 1000;
		}

		System.out.print("\n");
		if (!rdv.isConnectedToRendezVous()) {
			throw new RuntimeException("No RendezVous found for the peer group " + inGroup.getPeerGroupName());
			//printTo.write("Starting a RendezVous on this peer\n");
			//printTo.flush();
			//netRdv.startRendezVous();
		}
		else {
			System.out.println("Finished connecting to RendezVous.");
		}
	}
}

	